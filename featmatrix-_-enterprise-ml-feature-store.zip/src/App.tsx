/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header, ActiveTab } from './components/Header';
import { FeatureRegistry } from './components/FeatureRegistry';
import { OnlineServingPlayground } from './components/OnlineServingPlayground';
import { PointInTimeJoinView } from './components/PointInTimeJoinView';
import { LineageGraphView } from './components/LineageGraphView';
import { MonitoringDriftView } from './components/MonitoringDriftView';
import { DeclarativeCodeRepo } from './components/DeclarativeCodeRepo';
import { CreateFeatureModal } from './components/CreateFeatureModal';

import {
  INITIAL_ENTITIES,
  INITIAL_FEATURE_VIEWS,
  INITIAL_FEATURE_SERVICES
} from './data/mockFeatureStore';
import { FeatureView } from './types/featureStore';
import {
  Layers,
  Zap,
  Clock,
  GitFork,
  Activity,
  Code2,
  CheckCircle2,
  Database,
  Radio,
  Server,
  Terminal
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('registry');
  const [selectedEnv, setSelectedEnv] = useState('prod-us-east-1');
  const [entities, setEntities] = useState(INITIAL_ENTITIES);
  const [featureViews, setFeatureViews] = useState<FeatureView[]>(INITIAL_FEATURE_VIEWS);
  const [featureServices, setFeatureServices] = useState(INITIAL_FEATURE_SERVICES);

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [servingServiceId, setServingServiceId] = useState<string | undefined>(undefined);
  const [lineageNodeId, setLineageNodeId] = useState<string | undefined>(undefined);
  const [offlineFvId, setOfflineFvId] = useState<string | undefined>(undefined);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleCreateFeatureView = (newFv: FeatureView) => {
    setFeatureViews((prev) => [newFv, ...prev]);
    showToast(`Feature view '${newFv.name}' registered to ${selectedEnv}`);
  };

  const handleSelectServiceForServing = (serviceId: string) => {
    setServingServiceId(serviceId);
    setActiveTab('online_serving');
  };

  const handleNavigateToLineage = (nodeId: string) => {
    setLineageNodeId(nodeId);
    setActiveTab('lineage');
  };

  const handleNavigateToOfflineJoin = (fvId: string) => {
    setOfflineFvId(fvId);
    setActiveTab('offline_join');
  };

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 flex flex-col selection:bg-cyan-500/20 selection:text-cyan-300">
      {/* Top Bar Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openCreateModal={() => setIsCreateModalOpen(true)}
        selectedEnv={selectedEnv}
        setSelectedEnv={setSelectedEnv}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto p-4 lg:p-6">
        {activeTab === 'registry' && (
          <FeatureRegistry
            entities={entities}
            featureViews={featureViews}
            featureServices={featureServices}
            onSelectFeatureServiceForServing={handleSelectServiceForServing}
            onNavigateToLineage={handleNavigateToLineage}
            onNavigateToOfflineJoin={handleNavigateToOfflineJoin}
          />
        )}

        {activeTab === 'online_serving' && (
          <OnlineServingPlayground
            featureServices={featureServices}
            featureViews={featureViews}
            preselectedServiceId={servingServiceId}
          />
        )}

        {activeTab === 'offline_join' && (
          <PointInTimeJoinView
            featureViews={featureViews}
            preselectedFeatureViewId={offlineFvId}
          />
        )}

        {activeTab === 'lineage' && (
          <LineageGraphView initialSelectedNodeId={lineageNodeId} />
        )}

        {activeTab === 'monitoring' && <MonitoringDriftView />}

        {activeTab === 'declarative_repo' && <DeclarativeCodeRepo />}
      </main>

      {/* Footer conforming to anti-slop rules (clean, minimal copyright & site links, no fake engines) */}
      <footer className="border-t border-slate-800/80 bg-[#070b11] py-4 px-6 text-xs text-slate-500 font-mono">
        <div className="max-w-[1720px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-slate-400 font-bold">FeatMatrix Feature Store</span>
            <span aria-hidden="true">·</span>
            <span>Enterprise ML Feature Engineering & Serving Platform</span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>Sub-millisecond Online Retrieval</span>
            <span aria-hidden="true">·</span>
            <span>Time-Travel As-Of Joins</span>
            <span aria-hidden="true">·</span>
            <span>Feast & Tecton Compatible</span>
          </div>
        </div>
      </footer>

      {/* Create Feature View Modal */}
      <CreateFeatureModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        entities={entities}
        onCreate={handleCreateFeatureView}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 border border-cyan-500/50 text-cyan-300 text-xs font-mono shadow-2xl shadow-cyan-950/50 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
