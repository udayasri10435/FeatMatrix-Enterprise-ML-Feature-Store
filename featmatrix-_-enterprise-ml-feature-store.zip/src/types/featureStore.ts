export type DataType =
  | 'INT64'
  | 'FLOAT32'
  | 'STRING'
  | 'BOOLEAN'
  | 'VECTOR_128'
  | 'TIMESTAMP'
  | 'ARRAY_STRING';

export type TransformationType =
  | 'BATCH_SQL'
  | 'STREAM_FLINK'
  | 'ON_DEMAND_PYTHON'
  | 'EMBEDDING';

export type HealthStatus = 'HEALTHY' | 'WARNING' | 'CRITICAL';

export interface Entity {
  id: string;
  name: string;
  joinKey: string;
  valueType: string;
  description: string;
  owner: string;
  featureViewsCount: number;
  createdAt: string;
}

export interface FeatureMetricStats {
  min?: number;
  max?: number;
  mean?: number;
  stdDev?: number;
  uniqueValues?: number;
}

export interface FeatureItem {
  id: string;
  name: string;
  dataType: DataType;
  description: string;
  sampleValue: string | number | boolean | number[];
  nullRatio: number; // 0 to 1
  driftPsi: number; // Population Stability Index
  status: HealthStatus;
  stats?: FeatureMetricStats;
}

export interface FeatureView {
  id: string;
  name: string;
  version: string;
  description: string;
  entities: string[]; // join keys like user_id
  transformationType: TransformationType;
  source: {
    engine: 'Snowflake' | 'Kafka' | 'BigQuery' | 'S3_Parquet' | 'PostgreSQL';
    tableOrTopic: string;
    description: string;
  };
  features: FeatureItem[];
  onlineStore: {
    enabled: boolean;
    engine: 'Redis' | 'DynamoDB' | 'Bigtable';
    ttlDays: number;
    p99LatencyMs: number;
    sizeMb: number;
  };
  offlineStore: {
    enabled: boolean;
    engine: 'Snowflake' | 'Delta Lake' | 'BigQuery';
    partitionKey: string;
    schedule: string;
  };
  freshnessSlaMinutes: number;
  currentLagMinutes: number;
  owner: string;
  tags: string[];
  lastMaterializedAt: string;
  codeDefinition: string;
}

export interface FeatureService {
  id: string;
  name: string;
  version: string;
  description: string;
  featureViewIds: string[];
  featuresCount: number;
  targetModels: string[];
  qps: number;
  p99LatencyMs: number;
  cacheHitRate: number;
  owner: string;
  updatedAt: string;
}

export interface LineageNode {
  id: string;
  type: 'source' | 'transform' | 'feature_view' | 'feature_service' | 'model';
  name: string;
  category: string;
  x: number;
  y: number;
  status: HealthStatus;
  meta: Record<string, string>;
}

export interface LineageEdge {
  id: string;
  from: string;
  to: string;
  label?: string;
}

export interface ObservationRow {
  rowId: string;
  entityKey: string;
  entityValue: string;
  timestamp: string;
  targetLabel: number; // e.g. 0 or 1 for fraud/churn
  secondaryEntityKey?: string;
  secondaryEntityValue?: string;
}

export interface JoinedFeatureCell {
  featureName: string;
  value: any;
  eventTimestamp: string;
  lagSeconds: number;
  isLeaked: boolean;
}

export interface JoinedRow {
  rowId: string;
  entityValue: string;
  observationTimestamp: string;
  targetLabel: number;
  features: Record<string, JoinedFeatureCell>;
}

export interface DriftDistribution {
  bucket: string;
  baselinePct: number;
  servingPct: number;
}

export interface FeatureDriftReport {
  featureName: string;
  featureViewName: string;
  dataType: DataType;
  psi: number;
  ksScore: number;
  nullRate: number;
  nullRateBaseline: number;
  status: HealthStatus;
  lastUpdated: string;
  distribution: DriftDistribution[];
}
