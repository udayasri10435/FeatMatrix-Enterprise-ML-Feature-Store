import React, { useState } from 'react';
import {
  Code2,
  FolderGit2,
  Terminal,
  FileCode,
  Play,
  Copy,
  Check,
  CheckCircle2
} from 'lucide-react';

export const DeclarativeCodeRepo: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<'users.py' | 'stream.py' | 'cross.py' | 'feature_store.yaml'>('users.py');
  const [cliOutput, setCliOutput] = useState<string | null>(null);
  const [isExecutingCli, setIsExecutingCli] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  const fileContents: Record<string, string> = {
    'users.py': `# Definition of Batch Feature View (Feast & Tecton standard)
from datetime import timedelta
from featmatrix import (
    Entity,
    Field,
    Float32,
    Int64,
    batch_feature_view,
    SnowflakeSource
)

# 1. Declare Primary Entity
user_entity = Entity(
    name="user_id",
    join_keys=["user_id"],
    description="Global user account identifier"
)

# 2. Declare Raw Source Connector
snowflake_transactions = SnowflakeSource(
    database="PROD_DB",
    schema="PAYMENTS",
    table="TRANSACTIONS_RAW",
    timestamp_field="event_timestamp",
    created_timestamp_field="created_at"
)

# 3. Declare Batch Feature View with Lookback Window
@batch_feature_view(
    sources=[snowflake_transactions],
    entities=[user_entity],
    mode="spark_sql",
    ttl=timedelta(days=30),
    batch_schedule=timedelta(hours=6),
    online=True,
    offline=True,
    description="Aggregated user transaction activity over trailing 30 days"
)
def user_transaction_aggregates_30d(transactions):
    return """
    SELECT
        user_id,
        event_timestamp,
        COUNT(transaction_id) OVER w30d AS user_tx_count_30d,
        AVG(amount_usd) OVER w30d AS user_avg_tx_amount_30d,
        MAX(amount_usd) OVER w30d AS user_max_tx_amount_30d,
        COUNT(DISTINCT merchant_id) OVER w30d AS user_distinct_merchants_30d
    FROM transactions
    WINDOW w30d AS (
        PARTITION BY user_id
        ORDER BY event_timestamp
        RANGE BETWEEN INTERVAL 30 DAYS PRECEDING AND CURRENT ROW
    )
    """`,

    'stream.py': `# Sub-second Streaming Feature View using Apache Flink & Kafka
from datetime import timedelta
from featmatrix import (
    Entity,
    KafkaSource,
    stream_feature_view,
    SlidingEventTimeWindows,
    Time
)

kafka_payment_attempts = KafkaSource(
    name="kafka_payment_attempts",
    bootstrap_servers=["kafka.prod.internal:9092"],
    topic="prod.events.payment-attempts.v1",
    timestamp_field="event_time",
    watermark_delay_threshold=timedelta(seconds=5)
)

@stream_feature_view(
    source=kafka_payment_attempts,
    entities=[user_entity],
    mode="flink_datastream",
    aggregation_interval=timedelta(seconds=10),
    sliding_windows=[timedelta(minutes=10), timedelta(hours=1)],
    online=True,
    offline=True
)
def user_realtime_velocity_1h(stream):
    return stream.key_by(lambda e: e.user_id) \\
        .window(SlidingEventTimeWindows.of(Time.hours(1), Time.seconds(10))) \\
        .aggregate(UserVelocityAggregator())`,

    'cross.py': `# Request-Time On-Demand Transformation (Stateless Python)
from featmatrix import (
    on_demand_feature_view,
    RequestSource,
    Float32,
    Boolean
)
import math

request_context = RequestSource(
    schema={
        "amount_usd": Float32,
        "user_lat": Float32,
        "user_lon": Float32,
        "merchant_lat": Float32,
        "merchant_lon": Float32,
        "prior_orders_count": Float32
    }
)

@on_demand_feature_view(
    sources=[
        user_transaction_aggregates_30d,
        merchant_risk_profile,
        request_context
    ],
    mode="python"
)
def user_merchant_cross_features(user_agg, merchant, req):
    # Calculate Haversine distance between customer location and store
    dlat = math.radians(req['merchant_lat'] - req['user_lat'])
    dlon = math.radians(req['merchant_lon'] - req['user_lon'])
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(req['user_lat'])) *
         math.cos(math.radians(req['merchant_lat'])) *
         math.sin(dlon / 2) ** 2)
    distance_km = 6371 * 2 * math.asin(math.sqrt(a))

    # Anomaly ratio compared to 30-day baseline
    avg_amt = user_agg.get('user_avg_tx_amount_30d', 1.0)
    ratio = req['amount_usd'] / max(avg_amt, 0.01)

    return {
        "user_merchant_distance_km": round(distance_km, 2),
        "is_first_interaction_with_merchant": req.get('prior_orders_count', 0) == 0,
        "tx_to_avg_amount_ratio": round(ratio, 3)
    }`,

    'feature_store.yaml': `# Declarative Repo Configuration (GitOps driven)
project: fraud_and_recsys_core
version: 2
registry: s3://company-ml-feature-store-registry/prod/registry.db
provider: aws

online_store:
  type: redis
  connection_string: redis://red-prod-cluster.cache.internal:6379
  ssl: true
  ttl_enforcement: strict

offline_store:
  type: snowflake
  database: PROD_DB
  schema: FEATURE_STORE
  warehouse: ML_TRAINING_WH

flags:
  strict_point_in_time_enforcement: true
  prevent_lookahead_bias: true
  drift_monitoring_enabled: true`
  };

  const handleRunCli = (command: string) => {
    setIsExecutingCli(true);
    setCliOutput(null);

    setTimeout(() => {
      setIsExecutingCli(false);
      if (command === 'apply') {
        setCliOutput(`$ featmatrix apply
Validating feature definitions in ./features/...
✓ Loaded 4 Entities (user_id, merchant_id, device_id, listing_id)
✓ Validated 6 Feature Views (AST syntax & schema verified)
✓ Checked Redis cluster connection: OK (latency 0.8ms)
✓ Checked Snowflake schema 'PROD_DB.FEATURE_STORE': OK

Applying plan to Production Registry:
  + Registering FeatureView 'user_transaction_aggregates_30d' (v2.1)
  + Registering FeatureView 'user_realtime_velocity_1h' (v3.0)
  + Registering FeatureView 'user_merchant_cross_features' (v2.0)
  + Syncing Redis keyspace schemas & TTL indices... done

🎉 0 errors, 0 warnings. Registry successfully updated to commit 9d8b12f.`);
      } else if (command === 'test') {
        setCliOutput(`$ featmatrix test
Running declarative unit tests...
test_user_merchant_cross_features_distance ... [PASS] (0.002s)
test_ratio_calc_zero_division_guard ... [PASS] (0.001s)
test_stream_velocity_window_boundary ... [PASS] (0.014s)
test_pit_join_historical_consistency ... [PASS] (0.042s)

----------------------------------------------------------------------
Ran 4 unit tests in 0.059s.
ALL PASS: 4 passed, 0 failed.`);
      } else if (command === 'materialize') {
        setCliOutput(`$ featmatrix materialize 2026-09-01 2026-09-29
Starting incremental backfill for Redis Online Store...
[1/2] Materializing 'user_transaction_aggregates_30d':
      Scanning Snowflake partitions [2026-09-01 -> 2026-09-29]
      Writing 14,280,000 keys to Redis cluster...
      Progress: [====================================] 100% (42s)
[2/2] Materializing 'merchant_risk_profile':
      Scanning BigQuery table...
      Writing 240,000 keys to DynamoDB...
      Progress: [====================================] 100% (6s)

✓ Materialization complete. Online store TTL fresh.`);
      }
    }, 450);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(fileContents[selectedFile]);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Title & CLI Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            Declarative Code Repository (GitOps)
            <span className="text-xs font-mono font-normal text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800/50">
              Feast & Tecton Standard
            </span>
          </h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Features Defined as Python Code</span>
            <span aria-hidden="true">·</span>
            <span>Version Controlled with Git</span>
            <span aria-hidden="true">·</span>
            <span>CLI Migration & Materialization</span>
          </div>
        </div>

        {/* Quick CLI Actions */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => handleRunCli('apply')}
            disabled={isExecutingCli}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium shadow-sm transition-all"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>featmatrix apply</span>
          </button>
          <button
            onClick={() => handleRunCli('test')}
            disabled={isExecutingCli}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
          >
            <Terminal className="w-3 h-3" />
            <span>featmatrix test</span>
          </button>
          <button
            onClick={() => handleRunCli('materialize')}
            disabled={isExecutingCli}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
          >
            <Terminal className="w-3 h-3" />
            <span>featmatrix materialize</span>
          </button>
        </div>
      </div>

      {/* Main Code View + File Explorer + Terminal Console */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: File Tree Explorer */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-[#111726] border border-slate-800 rounded-xl overflow-hidden font-mono text-xs">
            <div className="p-3 bg-[#0b0f17] border-b border-slate-800 text-slate-400 flex items-center gap-2 font-bold font-sans">
              <FolderGit2 className="w-4 h-4 text-cyan-400" />
              <span>repo / features /</span>
            </div>

            <div className="p-2 space-y-1">
              <button
                onClick={() => setSelectedFile('users.py')}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left transition-colors ${
                  selectedFile === 'users.py'
                    ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-800/40 font-bold'
                    : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                }`}
              >
                <FileCode className="w-3.5 h-3.5 text-sky-400" />
                <span>users.py (Batch)</span>
              </button>

              <button
                onClick={() => setSelectedFile('stream.py')}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left transition-colors ${
                  selectedFile === 'stream.py'
                    ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-800/40 font-bold'
                    : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                }`}
              >
                <FileCode className="w-3.5 h-3.5 text-emerald-400" />
                <span>stream.py (Flink)</span>
              </button>

              <button
                onClick={() => setSelectedFile('cross.py')}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left transition-colors ${
                  selectedFile === 'cross.py'
                    ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-800/40 font-bold'
                    : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                }`}
              >
                <FileCode className="w-3.5 h-3.5 text-amber-400" />
                <span>cross.py (On-Demand)</span>
              </button>

              <button
                onClick={() => setSelectedFile('feature_store.yaml')}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left transition-colors ${
                  selectedFile === 'feature_store.yaml'
                    ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-800/40 font-bold'
                    : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                }`}
              >
                <FileCode className="w-3.5 h-3.5 text-purple-400" />
                <span>feature_store.yaml</span>
              </button>
            </div>
          </div>

          <div className="bg-[#111726] border border-slate-800 rounded-xl p-4 space-y-2 text-xs font-sans text-slate-300">
            <span className="font-bold text-white font-mono block">Why Declarative GitOps?</span>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Never configure features via unversioned web forms. Features are authored in Python, reviewed in pull requests, and deployed automatically via CI/CD using <code className="font-mono text-cyan-400">featmatrix apply</code>.
            </p>
          </div>
        </div>

        {/* Right: Code Editor & CLI Terminal output */}
        <div className="lg:col-span-9 space-y-4">
          <div className="bg-[#111726] border border-slate-800 rounded-xl overflow-hidden flex flex-col">
            {/* Header */}
            <div className="bg-[#0b0f17] border-b border-slate-800 px-4 py-2.5 flex items-center justify-between">
              <span className="font-mono text-xs font-semibold text-slate-300 flex items-center gap-2">
                <FileCode className="w-4 h-4 text-cyan-400" />
                {selectedFile}
              </span>

              <button
                onClick={handleCopyCode}
                className="flex items-center gap-1 text-xs text-slate-400 hover:text-slate-200 font-mono"
              >
                {copiedCode ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>

            {/* Code */}
            <div className="p-4 bg-[#070b11] font-mono text-xs text-slate-300 overflow-x-auto max-h-[460px] leading-relaxed">
              <pre>{fileContents[selectedFile]}</pre>
            </div>
          </div>

          {/* Interactive CLI Terminal output */}
          {(cliOutput || isExecutingCli) && (
            <div className="bg-[#05080e] border border-cyan-800/60 rounded-xl p-4 font-mono text-xs text-slate-300 space-y-2 shadow-xl shadow-cyan-950/20">
              <div className="flex items-center justify-between text-slate-500 border-b border-slate-800/80 pb-2">
                <span className="flex items-center gap-1.5 text-cyan-400 font-semibold">
                  <Terminal className="w-3.5 h-3.5" />
                  FeatMatrix CLI Console
                </span>
                <span className="text-[10px]">Session ID: term_0921a</span>
              </div>

              {isExecutingCli ? (
                <div className="flex items-center gap-2 text-cyan-400 py-3">
                  <div className="w-3.5 h-3.5 border-2 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin" />
                  <span>Executing featmatrix command...</span>
                </div>
              ) : (
                <pre className="text-slate-200 leading-relaxed overflow-x-auto whitespace-pre-wrap">
                  {cliOutput}
                </pre>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
