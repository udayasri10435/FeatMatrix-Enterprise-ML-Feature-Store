import React, { useState } from 'react';
import { FeatureDriftReport } from '../types/featureStore';
import { MOCK_DRIFT_REPORTS } from '../data/mockFeatureStore';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Bell,
  RefreshCw,
  Sliders,
  TrendingUp,
  BarChart3,
  Clock,
  Zap
} from 'lucide-react';

export const MonitoringDriftView: React.FC = () => {
  const [reports, setReports] = useState<FeatureDriftReport[]>(MOCK_DRIFT_REPORTS);
  const [selectedReport, setSelectedReport] = useState<FeatureDriftReport>(MOCK_DRIFT_REPORTS[0]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [alertPsiThreshold, setAlertPsiThreshold] = useState(0.20);
  const [driftInjected, setDriftInjected] = useState(false);

  const handleSimulateDrift = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      if (!driftInjected) {
        // Shift distribution to create significant drift
        const updated = reports.map((r) => {
          if (r.featureName === 'user_tx_count_30d') {
            return {
              ...r,
              psi: 0.285,
              ksScore: 0.21,
              status: 'CRITICAL' as const,
              lastUpdated: 'Just now',
              distribution: [
                { bucket: '0 - 5', baselinePct: 28.0, servingPct: 12.0 },
                { bucket: '6 - 15', baselinePct: 42.0, servingPct: 24.0 },
                { bucket: '16 - 30', baselinePct: 20.0, servingPct: 38.0 },
                { bucket: '31 - 60', baselinePct: 7.5, servingPct: 19.0 },
                { bucket: '> 60', baselinePct: 2.5, servingPct: 7.0 }
              ]
            };
          }
          return r;
        });
        setReports(updated);
        setSelectedReport(updated.find((r) => r.featureName === 'user_tx_count_30d')!);
        setDriftInjected(true);
      } else {
        // Reset to original
        setReports(MOCK_DRIFT_REPORTS);
        setSelectedReport(MOCK_DRIFT_REPORTS[0]);
        setDriftInjected(false);
      }
      setIsRefreshing(false);
    }, 400);
  };

  return (
    <div className="space-y-6">
      {/* Title & Drift Ingestion Test Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            Feature Quality & Drift Telemetry
            <span className="text-xs font-mono font-normal text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800/50">
              PSI & KS Engine
            </span>
          </h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Continuous Statistical Monitoring</span>
            <span aria-hidden="true">·</span>
            <span>Training vs Serving Skew Detection</span>
            <span aria-hidden="true">·</span>
            <span>Null-Rate Spike Guard</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleSimulateDrift}
            disabled={isRefreshing}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-mono rounded-lg transition-all ${
              driftInjected
                ? 'bg-amber-950/60 border border-amber-800 text-amber-300'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>{driftInjected ? 'Revert Simulated Drift' : 'Inject Traffic Drift'}</span>
          </button>

          <div className="flex items-center gap-2 bg-[#111726] border border-slate-800 px-3 py-1.5 rounded-lg text-xs font-mono">
            <span className="text-slate-400">PSI Alert Threshold:</span>
            <span className="text-cyan-400 font-bold">{alertPsiThreshold.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Grid: Feature Table on Left, Interactive Distribution Histogram on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Monitored Features List */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#111726] border border-slate-800 rounded-xl overflow-hidden">
            <div className="p-3 bg-[#0b0f17] border-b border-slate-800 text-xs font-bold text-slate-300 font-mono flex items-center justify-between">
              <span>Monitored Feature Metrics</span>
              <span className="text-[11px] text-slate-500 font-normal">
                {reports.length} features tracked
              </span>
            </div>

            <div className="divide-y divide-slate-800/60 font-mono text-xs">
              {reports.map((report) => {
                const isSelected = selectedReport.featureName === report.featureName;
                const isCritical = report.psi >= alertPsiThreshold;
                const isWarning = report.psi >= 0.1 && report.psi < alertPsiThreshold;

                return (
                  <div
                    key={report.featureName}
                    onClick={() => setSelectedReport(report)}
                    className={`p-3.5 cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-cyan-950/30 border-l-2 border-l-cyan-400'
                        : 'hover:bg-slate-800/30'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-slate-200 truncate">{report.featureName}</span>
                      <span
                        className={`text-[11px] px-1.5 py-0.5 rounded font-bold ${
                          isCritical
                            ? 'text-rose-400 bg-rose-950/60 border border-rose-800/50'
                            : isWarning
                            ? 'text-amber-400 bg-amber-950/60 border border-amber-800/50'
                            : 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/50'
                        }`}
                      >
                        PSI {report.psi.toFixed(3)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>View: {report.featureViewName}</span>
                      <span>Nulls: {(report.nullRate * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Automated Action Rules */}
          <div className="bg-[#111726] border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs">
            <span className="font-bold text-white uppercase text-[11px] tracking-wider font-sans block flex items-center gap-1.5">
              <Bell className="w-3.5 h-3.5 text-cyan-400" />
              Automated Pipeline Actions on Drift
            </span>
            <div className="space-y-2 text-slate-300">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  defaultChecked
                  className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
                />
                <span>Trigger Airflow retraining DAG when PSI &gt; {alertPsiThreshold}</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  defaultChecked
                  className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
                />
                <span>Page ML on-call via PagerDuty for null rate &gt; 2.0%</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  defaultChecked
                  className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
                />
                <span>Auto fallback to offline batch aggregates during stream lag</span>
              </label>
            </div>
          </div>
        </div>

        {/* Right: Detailed Distribution Histogram Inspector */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#111726] border border-slate-800 rounded-xl p-5 space-y-5">
            {/* Header */}
            <div className="flex items-start justify-between border-b border-slate-800 pb-4">
              <div>
                <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider block">
                  {selectedReport.featureViewName}
                </span>
                <h3 className="text-base font-bold text-white font-mono mt-0.5">
                  {selectedReport.featureName}
                </h3>
              </div>

              <div className="text-right font-mono">
                <span className="text-xs text-slate-400 block">Status</span>
                <span
                  className={`text-xs font-bold ${
                    selectedReport.psi >= alertPsiThreshold
                      ? 'text-rose-400'
                      : selectedReport.psi >= 0.1
                      ? 'text-amber-400'
                      : 'text-emerald-400'
                  }`}
                >
                  {selectedReport.psi >= alertPsiThreshold
                    ? 'CRITICAL DRIFT'
                    : selectedReport.psi >= 0.1
                    ? 'MODERATE DRIFT'
                    : 'NOMINAL STABILITY'}
                </span>
              </div>
            </div>

            {/* Metrics cards */}
            <div className="grid grid-cols-3 gap-3 bg-[#0b0f17] p-3 rounded-lg border border-slate-800 font-mono text-center">
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">PSI Distance</span>
                <span
                  className={`text-sm font-bold ${
                    selectedReport.psi >= alertPsiThreshold
                      ? 'text-rose-400'
                      : selectedReport.psi >= 0.1
                      ? 'text-amber-400'
                      : 'text-emerald-400'
                  }`}
                >
                  {selectedReport.psi.toFixed(3)}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">KS Statistic</span>
                <span className="text-sm font-bold text-slate-200">
                  {selectedReport.ksScore.toFixed(3)}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Null Ratio</span>
                <span className="text-sm font-bold text-slate-200">
                  {(selectedReport.nullRate * 100).toFixed(2)}%
                </span>
              </div>
            </div>

            {/* Interactive Histogram */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-white font-sans flex items-center gap-1.5">
                  <BarChart3 className="w-4 h-4 text-cyan-400" />
                  Population Distribution Comparison: Baseline vs Production Window
                </span>
                <div className="flex items-center gap-3 font-mono text-[11px]">
                  <span className="flex items-center gap-1.5 text-slate-400">
                    <span className="w-2.5 h-2.5 rounded bg-slate-600" />
                    Baseline (Training)
                  </span>
                  <span className="flex items-center gap-1.5 text-cyan-400">
                    <span className="w-2.5 h-2.5 rounded bg-cyan-500" />
                    Serving (Live Traffic)
                  </span>
                </div>
              </div>

              {/* Bucket Bars */}
              <div className="space-y-3.5 bg-[#0b0f17] p-4 rounded-xl border border-slate-800/80">
                {selectedReport.distribution.map((bucket) => {
                  const delta = bucket.servingPct - bucket.baselinePct;
                  return (
                    <div key={bucket.bucket} className="space-y-1.5 font-mono text-xs">
                      <div className="flex justify-between text-slate-300 text-[11px]">
                        <span className="font-semibold">{bucket.bucket}</span>
                        <div className="flex items-center gap-3">
                          <span className="text-slate-400">Base: {bucket.baselinePct}%</span>
                          <span className="text-cyan-300 font-bold">
                            Live: {bucket.servingPct}%
                          </span>
                          <span
                            className={`text-[10px] font-bold ${
                              Math.abs(delta) > 10
                                ? 'text-rose-400'
                                : Math.abs(delta) > 5
                                ? 'text-amber-400'
                                : 'text-slate-500'
                            }`}
                          >
                            {delta > 0 ? `+${delta.toFixed(1)}%` : `${delta.toFixed(1)}%`}
                          </span>
                        </div>
                      </div>

                      {/* Paired comparison bars */}
                      <div className="space-y-1">
                        {/* Baseline bar */}
                        <div className="h-2 bg-slate-800/80 rounded overflow-hidden">
                          <div
                            className="h-full bg-slate-500 transition-all duration-300"
                            style={{ width: `${Math.min(bucket.baselinePct * 1.5, 100)}%` }}
                          />
                        </div>
                        {/* Live Serving bar */}
                        <div className="h-2 bg-slate-800/80 rounded overflow-hidden">
                          <div
                            className={`h-full transition-all duration-300 ${
                              Math.abs(delta) > 10 ? 'bg-rose-500' : 'bg-cyan-400'
                            }`}
                            style={{ width: `${Math.min(bucket.servingPct * 1.5, 100)}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Diagnostic advice */}
            <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300 font-sans leading-relaxed">
              <span className="font-bold text-white font-mono block mb-1">
                Diagnostic Interpretation:
              </span>
              {selectedReport.psi >= alertPsiThreshold ? (
                <span className="text-rose-300">
                  Critical drift detected (PSI {selectedReport.psi.toFixed(3)} exceeds threshold {alertPsiThreshold}). The distribution in live production serving diverges significantly from the training reference set. Downstream model predictions are likely degraded. Retraining recommended.
                </span>
              ) : selectedReport.psi >= 0.1 ? (
                <span className="text-amber-300">
                  Moderate shift detected. Keep under observation. Check for macro seasonality or recent product taxonomy changes.
                </span>
              ) : (
                <span className="text-emerald-300">
                  Distribution is stable. PSI {selectedReport.psi.toFixed(3)} is well below tolerance limit. No model retrain required.
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
