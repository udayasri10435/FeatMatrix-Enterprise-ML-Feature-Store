import React, { useState } from 'react';
import {
  Entity,
  FeatureView,
  FeatureService,
  TransformationType,
  HealthStatus
} from '../types/featureStore';
import {
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Database,
  Radio,
  Cpu,
  Layers,
  Sparkles,
  ExternalLink,
  Copy,
  Check,
  ChevronRight,
  Server,
  Zap,
  Clock,
  Code
} from 'lucide-react';

interface FeatureRegistryProps {
  entities: Entity[];
  featureViews: FeatureView[];
  featureServices: FeatureService[];
  onSelectFeatureServiceForServing: (serviceId: string) => void;
  onNavigateToLineage: (nodeId: string) => void;
  onNavigateToOfflineJoin: (featureViewId: string) => void;
}

export const FeatureRegistry: React.FC<FeatureRegistryProps> = ({
  entities,
  featureViews,
  featureServices,
  onSelectFeatureServiceForServing,
  onNavigateToLineage,
  onNavigateToOfflineJoin
}) => {
  const [subTab, setSubTab] = useState<'views' | 'entities' | 'services'>('views');
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [selectedFeatureView, setSelectedFeatureView] = useState<FeatureView | null>(
    featureViews[0] || null
  );
  const [copiedCode, setCopiedCode] = useState(false);

  // Filter feature views
  const filteredFeatureViews = featureViews.filter((fv) => {
    const matchesSearch =
      fv.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fv.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fv.features.some((f) => f.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
      fv.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesType = typeFilter === 'ALL' || fv.transformationType === typeFilter;
    const matchesStatus =
      statusFilter === 'ALL' ||
      (statusFilter === 'HEALTHY' && fv.features.every((f) => f.status === 'HEALTHY')) ||
      (statusFilter === 'WARNING' && fv.features.some((f) => f.status === 'WARNING')) ||
      (statusFilter === 'CRITICAL' && fv.features.some((f) => f.status === 'CRITICAL'));

    return matchesSearch && matchesType && matchesStatus;
  });

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const getTransformBadge = (type: TransformationType) => {
    switch (type) {
      case 'BATCH_SQL':
        return (
          <span className="flex items-center gap-1.5 text-xs text-sky-400 font-mono">
            <Database className="w-3.5 h-3.5" />
            Batch (SQL/Spark)
          </span>
        );
      case 'STREAM_FLINK':
        return (
          <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
            <Radio className="w-3.5 h-3.5" />
            Stream (Kafka/Flink)
          </span>
        );
      case 'ON_DEMAND_PYTHON':
        return (
          <span className="flex items-center gap-1.5 text-xs text-amber-400 font-mono">
            <Cpu className="w-3.5 h-3.5" />
            On-Demand (Python)
          </span>
        );
      case 'EMBEDDING':
        return (
          <span className="flex items-center gap-1.5 text-xs text-purple-400 font-mono">
            <Sparkles className="w-3.5 h-3.5" />
            Vector Embedding
          </span>
        );
    }
  };

  const getStatusIndicator = (status: HealthStatus) => {
    switch (status) {
      case 'HEALTHY':
        return (
          <span className="flex items-center gap-1.5 text-xs text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Nominal</span>
          </span>
        );
      case 'WARNING':
        return (
          <span className="flex items-center gap-1.5 text-xs text-amber-400">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Drift Warning</span>
          </span>
        );
      case 'CRITICAL':
        return (
          <span className="flex items-center gap-1.5 text-xs text-rose-400">
            <XCircle className="w-3.5 h-3.5" />
            <span>SLA Breach</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Section: Overview Stats & Search/Subtabs */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Unified Feature Catalog</h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Enterprise Registry</span>
            <span aria-hidden="true">·</span>
            <span>Single Source of Truth for Training & Serving</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-cyan-400">{featureViews.length} Feature Views</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-cyan-400">
              {featureViews.reduce((acc, fv) => acc + fv.features.length, 0)} Features Active
            </span>
          </div>
        </div>

        {/* Subtabs */}
        <div className="flex items-center p-1 bg-[#111726] border border-slate-800 rounded-lg">
          <button
            onClick={() => setSubTab('views')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              subTab === 'views'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Feature Views ({featureViews.length})
          </button>
          <button
            onClick={() => setSubTab('entities')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              subTab === 'entities'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Entities ({entities.length})
          </button>
          <button
            onClick={() => setSubTab('services')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              subTab === 'services'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Feature Services ({featureServices.length})
          </button>
        </div>
      </div>

      {/* Main Content Area based on SubTab */}
      {subTab === 'views' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Filters and Table List */}
          <div className="lg:col-span-7 space-y-4">
            {/* Filter Bar */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search features, views, tags, entities..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#111726] border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex gap-2">
                <select
                  value={typeFilter}
                  onChange={(e) => setTypeFilter(e.target.value)}
                  aria-label="Filter by Source Type"
                  className="bg-[#111726] border border-slate-800 text-slate-300 text-xs rounded-lg px-2.5 py-2 focus:outline-none focus:border-cyan-500 font-mono"
                >
                  <option value="ALL">All Types</option>
                  <option value="BATCH_SQL">Batch SQL</option>
                  <option value="STREAM_FLINK">Stream Flink</option>
                  <option value="ON_DEMAND_PYTHON">On-Demand</option>
                  <option value="EMBEDDING">Vector</option>
                </select>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  aria-label="Filter by Health Status"
                  className="bg-[#111726] border border-slate-800 text-slate-300 text-xs rounded-lg px-2.5 py-2 focus:outline-none focus:border-cyan-500"
                >
                  <option value="ALL">All Health</option>
                  <option value="HEALTHY">Nominal</option>
                  <option value="WARNING">Drift Warning</option>
                  <option value="CRITICAL">SLA Breach</option>
                </select>
              </div>
            </div>

            {/* Feature Views Table */}
            <div className="bg-[#111726]/70 border border-slate-800/90 rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#0b0f17] text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4 font-semibold">Feature View</th>
                      <th className="py-3 px-4 font-semibold">Type</th>
                      <th className="py-3 px-4 font-semibold">Entity Key</th>
                      <th className="py-3 px-4 font-semibold text-right">Features</th>
                      <th className="py-3 px-4 font-semibold text-right">Freshness Lag</th>
                      <th className="py-3 px-4 font-semibold">Online Store</th>
                      <th className="py-3 px-4 font-semibold text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {filteredFeatureViews.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center py-10 text-slate-500">
                          No feature views match the selected query or filters.
                        </td>
                      </tr>
                    ) : (
                      filteredFeatureViews.map((fv) => {
                        const isSelected = selectedFeatureView?.id === fv.id;
                        const hasCritical = fv.features.some((f) => f.status === 'CRITICAL');
                        const hasWarning = fv.features.some((f) => f.status === 'WARNING');
                        const overallStatus: HealthStatus = hasCritical
                          ? 'CRITICAL'
                          : hasWarning
                          ? 'WARNING'
                          : 'HEALTHY';

                        return (
                          <tr
                            key={fv.id}
                            onClick={() => setSelectedFeatureView(fv)}
                            className={`cursor-pointer transition-colors ${
                              isSelected
                                ? 'bg-cyan-950/30 border-l-2 border-l-cyan-400'
                                : 'hover:bg-slate-800/30'
                            }`}
                          >
                            <td className="py-3 px-4">
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-slate-200 font-mono">
                                  {fv.name}
                                </span>
                                <span className="text-[10px] text-slate-400 font-mono">
                                  {fv.version}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                                {fv.description}
                              </p>
                            </td>

                            <td className="py-3 px-4 whitespace-nowrap">
                              {getTransformBadge(fv.transformationType)}
                            </td>

                            <td className="py-3 px-4 whitespace-nowrap">
                              <div className="flex items-center gap-1 font-mono text-cyan-300">
                                {fv.entities.join(', ')}
                              </div>
                            </td>

                            <td className="py-3 px-4 text-right font-mono font-medium text-slate-300">
                              {fv.features.length}
                            </td>

                            <td className="py-3 px-4 text-right font-mono">
                              <span
                                className={
                                  fv.currentLagMinutes > fv.freshnessSlaMinutes
                                    ? 'text-rose-400 font-semibold'
                                    : 'text-slate-300'
                                }
                              >
                                {fv.currentLagMinutes < 1
                                  ? `${Math.round(fv.currentLagMinutes * 60)}s`
                                  : `${Math.round(fv.currentLagMinutes)}m`}
                              </span>
                              <span className="text-slate-500 text-[10px] block">
                                SLA: {fv.freshnessSlaMinutes}m
                              </span>
                            </td>

                            <td className="py-3 px-4 whitespace-nowrap">
                              {fv.onlineStore.enabled ? (
                                <span className="font-mono text-slate-300 flex items-center gap-1">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
                                  {fv.onlineStore.engine} ({fv.onlineStore.p99LatencyMs}ms)
                                </span>
                              ) : (
                                <span className="text-slate-500 font-mono">Off (Batch-only)</span>
                              )}
                            </td>

                            <td className="py-3 px-4 whitespace-nowrap text-center">
                              {getStatusIndicator(overallStatus)}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Right Column: Detailed Inspector Drawer */}
          <div className="lg:col-span-5">
            {selectedFeatureView ? (
              <div className="bg-[#111726] border border-slate-800 rounded-xl p-5 space-y-5 sticky top-20">
                {/* Header */}
                <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-base font-bold text-white font-mono">
                        {selectedFeatureView.name}
                      </h2>
                      <span className="text-xs font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800/60">
                        {selectedFeatureView.version}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      {selectedFeatureView.description}
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => onNavigateToLineage(selectedFeatureView.id)}
                      className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1"
                      title="Inspect in Lineage DAG"
                    >
                      <Layers className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Lineage</span>
                    </button>
                    <button
                      onClick={() => onNavigateToOfflineJoin(selectedFeatureView.id)}
                      className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1"
                      title="Historical As-Of Join"
                    >
                      <Clock className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Join</span>
                    </button>
                  </div>
                </div>

                {/* Metadata row */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#0b0f17] p-3 rounded-lg border border-slate-800/80 text-xs">
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase font-mono">
                      Join Entities
                    </span>
                    <span className="font-mono text-cyan-300 font-semibold">
                      {selectedFeatureView.entities.join(', ')}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase font-mono">
                      Data Source
                    </span>
                    <span className="font-mono text-slate-300 font-medium">
                      {selectedFeatureView.source.engine}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase font-mono">
                      Online P99
                    </span>
                    <span className="font-mono text-emerald-400 font-semibold">
                      {selectedFeatureView.onlineStore.enabled
                        ? `${selectedFeatureView.onlineStore.p99LatencyMs} ms`
                        : 'N/A'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px] uppercase font-mono">
                      Owner
                    </span>
                    <span className="text-slate-300 truncate block">
                      {selectedFeatureView.owner.split('@')[0]}
                    </span>
                  </div>
                </div>

                {/* Feature Schema Table */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-300">
                      Feature Schema & Statistics ({selectedFeatureView.features.length})
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Sync: {selectedFeatureView.lastMaterializedAt}
                    </span>
                  </div>

                  <div className="border border-slate-800 rounded-lg overflow-hidden bg-[#0b0f17]">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-900/80 text-slate-400 border-b border-slate-800">
                        <tr>
                          <th className="py-2 px-3 font-medium">Feature Name</th>
                          <th className="py-2 px-3 font-medium">Type</th>
                          <th className="py-2 px-3 font-medium text-right">Drift (PSI)</th>
                          <th className="py-2 px-3 font-medium">Sample Value</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 font-mono">
                        {selectedFeatureView.features.map((f) => (
                          <tr key={f.id} className="hover:bg-slate-800/20">
                            <td className="py-2 px-3">
                              <span className="text-slate-200 font-semibold block">{f.name}</span>
                              <span className="text-[10px] font-sans text-slate-400 block line-clamp-1">
                                {f.description}
                              </span>
                            </td>
                            <td className="py-2 px-3 text-cyan-400 text-[11px]">{f.dataType}</td>
                            <td className="py-2 px-3 text-right">
                              <span
                                className={`text-[11px] ${
                                  f.driftPsi > 0.2
                                    ? 'text-rose-400 font-bold'
                                    : f.driftPsi > 0.1
                                    ? 'text-amber-400'
                                    : 'text-slate-300'
                                }`}
                              >
                                {f.driftPsi.toFixed(3)}
                              </span>
                            </td>
                            <td className="py-2 px-3 text-slate-400 text-[11px] truncate max-w-[140px]">
                              {Array.isArray(f.sampleValue)
                                ? `[${f.sampleValue.slice(0, 3).join(', ')} ...]`
                                : String(f.sampleValue)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Declarative Transformation Code Preview */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                      <Code className="w-3.5 h-3.5 text-cyan-400" />
                      Transformation Logic (Python / SQL)
                    </span>
                    <button
                      onClick={() => handleCopyCode(selectedFeatureView.codeDefinition)}
                      className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
                    >
                      {copiedCode ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="relative rounded-lg bg-[#070b11] border border-slate-800 p-3 overflow-x-auto max-h-56">
                    <pre className="text-[11px] font-mono text-slate-300 leading-relaxed">
                      {selectedFeatureView.codeDefinition}
                    </pre>
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* Subtab: Entities View */}
      {subTab === 'entities' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {entities.map((entity) => (
            <div
              key={entity.id}
              className="bg-[#111726] border border-slate-800 rounded-xl p-5 space-y-4 hover:border-slate-700 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-white text-base font-mono">{entity.name}</h3>
                  <span className="text-xs font-mono text-cyan-400 mt-1 block">
                    Join Key: <span className="font-bold">{entity.joinKey}</span>
                  </span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-cyan-950/60 border border-cyan-800/40 flex items-center justify-center text-cyan-400 font-mono text-xs">
                  {entity.joinKey.slice(0, 2)}
                </div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">{entity.description}</p>

              <div className="border-t border-slate-800/80 pt-3 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-500">Value Type:</span>
                <span className="text-slate-300">{entity.valueType}</span>
              </div>

              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-500">Attached Views:</span>
                <span className="text-cyan-400 font-bold">{entity.featureViewsCount}</span>
              </div>

              <div className="text-[11px] text-slate-500 pt-1">
                Owner: {entity.owner}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Subtab: Feature Services View */}
      {subTab === 'services' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {featureServices.map((service) => (
            <div
              key={service.id}
              className="bg-[#111726] border border-slate-800 rounded-xl p-5 space-y-4 flex flex-col justify-between hover:border-slate-700 transition-colors"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white text-base font-mono">{service.name}</h3>
                    <span className="text-xs font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800/60">
                      {service.version}
                    </span>
                  </div>
                  <span className="flex items-center gap-1 text-xs text-emerald-400 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Online
                  </span>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed">{service.description}</p>

                <div className="grid grid-cols-3 gap-2 bg-[#0b0f17] p-2.5 rounded-lg border border-slate-800 text-center font-mono">
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase">Traffic QPS</span>
                    <span className="text-xs font-bold text-white">{service.qps.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase">P99 Latency</span>
                    <span className="text-xs font-bold text-emerald-400">{service.p99LatencyMs}ms</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase">Cache Hit</span>
                    <span className="text-xs font-bold text-cyan-400">{service.cacheHitRate}%</span>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs">
                  <span className="text-slate-500 block text-[11px] font-medium">Consumer ML Endpoints:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {service.targetModels.map((model) => (
                      <span
                        key={model}
                        className="px-2 py-0.5 rounded bg-slate-800/70 border border-slate-700/60 text-slate-300 font-mono text-[11px]"
                      >
                        {model}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                <span className="text-xs font-mono text-slate-400">
                  {service.featuresCount} Features Packaged
                </span>
                <button
                  onClick={() => onSelectFeatureServiceForServing(service.id)}
                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors font-mono"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>Test Online API</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
