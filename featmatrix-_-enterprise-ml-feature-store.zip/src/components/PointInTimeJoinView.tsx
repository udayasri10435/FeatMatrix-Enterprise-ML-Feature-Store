import React, { useState } from 'react';
import { FeatureView, ObservationRow } from '../types/featureStore';
import { MOCK_OBSERVATIONS } from '../data/mockFeatureStore';
import {
  Clock,
  ShieldCheck,
  AlertTriangle,
  Play,
  Download,
  Calendar,
  Layers,
  ArrowRight,
  Info,
  CheckCircle2,
  FileSpreadsheet,
  Lock,
  Unlock
} from 'lucide-react';

interface PointInTimeJoinViewProps {
  featureViews: FeatureView[];
  preselectedFeatureViewId?: string;
}

export const PointInTimeJoinView: React.FC<PointInTimeJoinViewProps> = ({
  featureViews,
  preselectedFeatureViewId
}) => {
  const [selectedFvIds, setSelectedFvIds] = useState<string[]>([
    preselectedFeatureViewId || 'fv_user_tx_aggregates_30d',
    'fv_merchant_risk_profile'
  ]);
  const [lookbackDays, setLookbackDays] = useState(30);
  const [joinMode, setJoinMode] = useState<'POINT_IN_TIME' | 'NAIVE_LEAKY'>('POINT_IN_TIME');
  const [isExecutingJoin, setIsExecutingJoin] = useState(false);
  const [hasExecuted, setHasExecuted] = useState(true);

  const toggleFeatureView = (id: string) => {
    setSelectedFvIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleExecuteJoin = () => {
    setIsExecutingJoin(true);
    setTimeout(() => {
      setIsExecutingJoin(false);
      setHasExecuted(true);
    }, 450);
  };

  // Build joined data based on mode
  const joinedRows = MOCK_OBSERVATIONS.map((obs) => {
    if (joinMode === 'POINT_IN_TIME') {
      // Historical point-in-time correct: strictly before observation timestamp
      return {
        rowId: obs.rowId,
        entityValue: obs.entityValue,
        secondaryValue: obs.secondaryEntityValue,
        observationTimestamp: obs.timestamp,
        targetLabel: obs.targetLabel,
        featureTimestamp: new Date(new Date(obs.timestamp).getTime() - 3.5 * 3600 * 1000).toISOString(),
        userTxCount30d: obs.rowId === 'obs_004' ? 18 : obs.rowId === 'obs_001' ? 14 : 9,
        userAvgAmount30d: obs.rowId === 'obs_004' ? 310.5 : 72.4,
        merchantChargebackRate: 0.0035,
        lagMinutes: 210,
        isLeaked: false
      };
    } else {
      // Naive join: leaks future data (e.g. today's totals or end-of-month aggregate)
      return {
        rowId: obs.rowId,
        entityValue: obs.entityValue,
        secondaryValue: obs.secondaryEntityValue,
        observationTimestamp: obs.timestamp,
        targetLabel: obs.targetLabel,
        featureTimestamp: '2026-09-29T00:00:00Z (LATEST_CURRENT_SNAPSHOT)',
        userTxCount30d: obs.rowId === 'obs_004' ? 44 : 26, // includes transactions that happened AFTER observation!
        userAvgAmount30d: obs.rowId === 'obs_004' ? 840.0 : 88.0,
        merchantChargebackRate: 0.0125, // includes disputes filed weeks later!
        lagMinutes: -48900,
        isLeaked: true
      };
    }
  });

  const downloadSampleCsv = () => {
    const headers = [
      'row_id',
      'entity_user_id',
      'entity_merchant_id',
      'event_timestamp',
      'target_label',
      'user_tx_count_30d',
      'user_avg_amount_30d',
      'merchant_chargeback_rate_90d',
      'pit_verified'
    ];
    const rows = joinedRows.map((r) =>
      [
        r.rowId,
        r.entityValue,
        r.secondaryValue,
        r.observationTimestamp,
        r.targetLabel,
        r.userTxCount30d,
        r.userAvgAmount30d,
        r.merchantChargebackRate,
        !r.isLeaked
      ].join(',')
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `training_dataset_as_of_${joinMode.toLowerCase()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            Point-in-Time Offline Join (Time-Travel)
            <span className="text-xs font-mono font-normal text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800/50">
              Zero Target Leakage
            </span>
          </h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Historical As-Of Join Engine</span>
            <span aria-hidden="true">·</span>
            <span>Prevent Lookahead Bias in Training Sets</span>
            <span aria-hidden="true">·</span>
            <span>Snowflake & Delta Lake Partition Scanning</span>
          </div>
        </div>

        {/* Join Mode Comparison Switcher */}
        <div className="flex items-center gap-2 bg-[#111726] border border-slate-800 p-1 rounded-xl">
          <button
            onClick={() => setJoinMode('POINT_IN_TIME')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
              joinMode === 'POINT_IN_TIME'
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>FeatMatrix Point-in-Time (Leak-Free)</span>
          </button>
          <button
            onClick={() => setJoinMode('NAIVE_LEAKY')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
              joinMode === 'NAIVE_LEAKY'
                ? 'bg-rose-500/15 text-rose-400 border border-rose-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Naive SQL Join (Simulate Leakage)</span>
          </button>
        </div>
      </div>

      {/* Visual Explanation of the Problem Feast / Tecton Solves */}
      <div
        className={`p-4 rounded-xl border transition-all text-xs font-mono ${
          joinMode === 'POINT_IN_TIME'
            ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-300'
            : 'bg-rose-950/20 border-rose-800/40 text-rose-300'
        }`}
      >
        <div className="flex items-start gap-3">
          {joinMode === 'POINT_IN_TIME' ? (
            <Lock className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          ) : (
            <Unlock className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          )}

          <div className="space-y-1 font-sans">
            <h3 className="font-bold text-sm">
              {joinMode === 'POINT_IN_TIME'
                ? 'Strict As-Of Point-in-Time Join Activated'
                : 'Warning: Naive Snapshot Join Leaking Future Data into Training Labels'}
            </h3>
            <p className="text-slate-300 text-xs leading-relaxed">
              {joinMode === 'POINT_IN_TIME'
                ? 'For every row in your observation dataset, FeatMatrix scans the feature view timeline backwards to join the newest feature version materialized at or before (observation_timestamp). Events that occurred after the observation event are strictly excluded, eliminating train/serve skew.'
                : 'A naive SQL left join binds the latest current snapshot of the feature table. The training set will accidentally include future transactions that occurred AFTER the fraud event took place. This produces fake 99.8% training accuracy that immediately collapses in real-time inference.'}
            </p>
          </div>
        </div>
      </div>

      {/* Control Configuration Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-[#111726] border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
            <h2 className="font-bold text-white text-xs uppercase tracking-wider font-sans border-b border-slate-800 pb-2">
              Join Job Configuration
            </h2>

            {/* Step 1: Observation Data */}
            <div className="space-y-1.5">
              <label className="text-slate-400 block font-sans font-medium text-[11px]">
                1. Historical Observation Dataset:
              </label>
              <div className="bg-[#0b0f17] border border-slate-800 rounded-lg p-2.5 space-y-1">
                <span className="text-cyan-300 font-bold block">
                  fraud_labeled_events_q3_2026.parquet
                </span>
                <span className="text-slate-400 text-[11px] block font-sans">
                  5 historical transaction records with timestamped target labels (0 = genuine, 1 = chargeback).
                </span>
              </div>
            </div>

            {/* Step 2: Feature Views Selection */}
            <div className="space-y-2">
              <label className="text-slate-400 block font-sans font-medium text-[11px]">
                2. Select Feature Views to Join:
              </label>
              <div className="space-y-1.5">
                {featureViews.slice(0, 4).map((fv) => {
                  const isChecked = selectedFvIds.includes(fv.id);
                  return (
                    <label
                      key={fv.id}
                      className={`flex items-start gap-2.5 p-2 rounded-lg border cursor-pointer transition-colors ${
                        isChecked
                          ? 'bg-cyan-950/30 border-cyan-800/60 text-slate-200'
                          : 'bg-[#0b0f17] border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => toggleFeatureView(fv.id)}
                        className="mt-0.5 rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
                      />
                      <div className="flex-1">
                        <span className="font-semibold block">{fv.name}</span>
                        <span className="text-[10px] text-slate-400 font-sans block">
                          Join keys: {fv.entities.join(', ')} ({fv.features.length} features)
                        </span>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Step 3: Lookback window TTL */}
            <div className="space-y-1.5 border-t border-slate-800 pt-3">
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400 font-sans">Max Lookback Window (TTL):</span>
                <span className="text-cyan-400 font-bold">{lookbackDays} Days</span>
              </div>
              <input
                type="range"
                min="1"
                max="90"
                value={lookbackDays}
                onChange={(e) => setLookbackDays(Number(e.target.value))}
                className="w-full accent-cyan-500"
              />
              <span className="text-[10px] text-slate-500 font-sans block">
                Features older than {lookbackDays} days prior to event will be evaluated as NULL.
              </span>
            </div>

            {/* Execute Button */}
            <button
              onClick={handleExecuteJoin}
              disabled={isExecutingJoin}
              className="w-full py-2.5 px-4 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-medium text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-900/30 font-mono transition-all"
            >
              {isExecutingJoin ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Computing As-Of Partitions...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Execute Time-Travel Join</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Interactive Joined Data Matrix */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-[#111726] border border-slate-800 rounded-xl overflow-hidden flex flex-col">
            <div className="bg-[#0b0f17] border-b border-slate-800 px-4 py-3 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white font-mono flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-cyan-400" />
                  Joined Feature Matrix (Spark / DuckDB Preview)
                </span>
                <span className="text-[11px] text-slate-400 font-sans mt-0.5 block">
                  {joinedRows.length} observation rows joined across {selectedFvIds.length} Feature Views
                </span>
              </div>

              <button
                onClick={downloadSampleCsv}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                <span>Export Dataset (.csv)</span>
              </button>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#0d131f] text-slate-400 border-b border-slate-800 text-[11px]">
                  <tr>
                    <th className="py-2.5 px-3 font-semibold">Row / Entity</th>
                    <th className="py-2.5 px-3 font-semibold">Observation Event Timestamp</th>
                    <th className="py-2.5 px-3 font-semibold">Feature Snapshot Timestamp</th>
                    <th className="py-2.5 px-3 font-semibold text-right">user_tx_count_30d</th>
                    <th className="py-2.5 px-3 font-semibold text-right">user_avg_amount</th>
                    <th className="py-2.5 px-3 font-semibold text-right">chargeback_rate</th>
                    <th className="py-2.5 px-3 font-semibold text-center">Leakage Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {joinedRows.map((row) => (
                    <tr
                      key={row.rowId}
                      className={row.isLeaked ? 'bg-rose-950/15 hover:bg-rose-950/25' : 'hover:bg-slate-800/20'}
                    >
                      <td className="py-2.5 px-3">
                        <span className="text-white font-bold block">{row.rowId}</span>
                        <span className="text-cyan-400 text-[10px] block">{row.entityValue}</span>
                        <span className="text-slate-500 text-[10px] block">{row.secondaryValue}</span>
                      </td>

                      <td className="py-2.5 px-3">
                        <span className="text-slate-200 block">{row.observationTimestamp}</span>
                        <span className="text-[10px] text-slate-500 font-sans">
                          Target Label: <span className="font-bold text-white">{row.targetLabel}</span>
                        </span>
                      </td>

                      <td className="py-2.5 px-3">
                        <span
                          className={`block ${
                            row.isLeaked ? 'text-rose-400 font-bold' : 'text-emerald-400'
                          }`}
                        >
                          {row.featureTimestamp}
                        </span>
                        {!row.isLeaked ? (
                          <span className="text-[10px] text-slate-400 block font-sans">
                            Joined {row.lagMinutes} mins prior to event
                          </span>
                        ) : (
                          <span className="text-[10px] text-rose-300 block font-sans font-semibold">
                            ⚠️ Future snapshot (leaks {Math.abs(Math.round(row.lagMinutes / 60))} hours ahead)
                          </span>
                        )}
                      </td>

                      <td className="py-2.5 px-3 text-right">
                        <span className={row.isLeaked ? 'text-rose-300 font-bold' : 'text-slate-200'}>
                          {row.userTxCount30d}
                        </span>
                      </td>

                      <td className="py-2.5 px-3 text-right">
                        <span className={row.isLeaked ? 'text-rose-300 font-bold' : 'text-slate-200'}>
                          ${row.userAvgAmount30d.toFixed(2)}
                        </span>
                      </td>

                      <td className="py-2.5 px-3 text-right">
                        <span className={row.isLeaked ? 'text-rose-300 font-bold' : 'text-slate-200'}>
                          {(row.merchantChargebackRate * 100).toFixed(2)}%
                        </span>
                      </td>

                      <td className="py-2.5 px-3 text-center whitespace-nowrap">
                        {!row.isLeaked ? (
                          <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
                            <CheckCircle2 className="w-3 h-3" />
                            Verified Safe
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] text-rose-400 bg-rose-950/60 px-2 py-0.5 rounded border border-rose-800/40">
                            <AlertTriangle className="w-3 h-3" />
                            Target Leaked
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Offline Engine Code snippet footer */}
            <div className="p-3 bg-[#070b11] border-t border-slate-800 text-[11px] font-mono text-slate-400 flex items-center justify-between">
              <span>FeatMatrix Query Engine: Spark Delta Lake Point-in-Time Joiner v3</span>
              <span className="text-slate-500">Scan partition time: 420ms · 0 bytes leaked</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
