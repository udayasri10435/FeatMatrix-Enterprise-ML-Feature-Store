import React, { useState, useMemo } from 'react';
import { LineageNode, LineageEdge } from '../types/featureStore';
import {
  INITIAL_LINEAGE_NODES,
  INITIAL_LINEAGE_EDGES
} from '../data/mockFeatureStore';
import {
  GitFork,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Layers,
  Database,
  Radio,
  Cpu,
  Server,
  Zap,
  CheckCircle2,
  AlertTriangle,
  X,
  ExternalLink,
  Info
} from 'lucide-react';

interface LineageGraphViewProps {
  initialSelectedNodeId?: string;
}

export const LineageGraphView: React.FC<LineageGraphViewProps> = ({
  initialSelectedNodeId
}) => {
  const [nodes] = useState<LineageNode[]>(INITIAL_LINEAGE_NODES);
  const [edges] = useState<LineageEdge[]>(INITIAL_LINEAGE_EDGES);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(
    initialSelectedNodeId || 'fv_user_tx_aggregates_30d'
  );
  const [pipelineFilter, setPipelineFilter] = useState<'ALL' | 'FRAUD' | 'RECSYS'>('ALL');
  const [zoomLevel, setZoomLevel] = useState(1);

  // Compute upstream ancestors and downstream descendants for highlighting
  const { upstreamNodeIds, downstreamNodeIds } = useMemo(() => {
    if (!selectedNodeId) return { upstreamNodeIds: new Set<string>(), downstreamNodeIds: new Set<string>() };

    const up = new Set<string>();
    const down = new Set<string>();

    // Traverse upstream
    const queueUp = [selectedNodeId];
    while (queueUp.length > 0) {
      const curr = queueUp.shift()!;
      edges.forEach((e) => {
        if (e.to === curr && !up.has(e.from)) {
          up.add(e.from);
          queueUp.push(e.from);
        }
      });
    }

    // Traverse downstream
    const queueDown = [selectedNodeId];
    while (queueDown.length > 0) {
      const curr = queueDown.shift()!;
      edges.forEach((e) => {
        if (e.from === curr && !down.has(e.to)) {
          down.add(e.to);
          queueDown.push(e.to);
        }
      });
    }

    return { upstreamNodeIds: up, downstreamNodeIds: down };
  }, [selectedNodeId, edges]);

  // Filter nodes based on active pipeline filter
  const visibleNodes = useMemo(() => {
    if (pipelineFilter === 'ALL') return nodes;
    if (pipelineFilter === 'FRAUD') {
      const fraudSet = new Set([
        'src_snowflake_tx',
        'src_kafka_payments',
        'src_bigquery_merchants',
        'tr_spark_agg',
        'tr_flink_velocity',
        'tr_bq_scheduled_sql',
        'fv_user_tx_aggregates_30d',
        'fv_user_realtime_velocity_1h',
        'fv_merchant_risk_profile',
        'fv_user_merchant_cross_features',
        'fs_fraud_scoring_realtime_v4',
        'model_xgboost_fraud'
      ]);
      return nodes.filter((n) => fraudSet.has(n.id));
    }
    if (pipelineFilter === 'RECSYS') {
      const recsysSet = new Set([
        'src_s3_parquet_logs',
        'src_snowflake_tx',
        'tr_two_tower_inference',
        'tr_spark_agg',
        'fv_user_semantic_embedding',
        'fv_user_tx_aggregates_30d',
        'fs_recsys_personalization_v2',
        'model_recsys_two_tower'
      ]);
      return nodes.filter((n) => recsysSet.has(n.id));
    }
    return nodes;
  }, [pipelineFilter, nodes]);

  const visibleEdges = useMemo(() => {
    const nodeIds = new Set(visibleNodes.map((n) => n.id));
    return edges.filter((e) => nodeIds.has(e.from) && nodeIds.has(e.to));
  }, [visibleNodes, edges]);

  const selectedNode = nodes.find((n) => n.id === selectedNodeId);

  const getNodeColor = (type: LineageNode['type']) => {
    switch (type) {
      case 'source':
        return {
          bg: 'bg-blue-950/40',
          border: 'border-blue-700/60',
          text: 'text-blue-400',
          icon: Database
        };
      case 'transform':
        return {
          bg: 'bg-amber-950/40',
          border: 'border-amber-700/60',
          text: 'text-amber-400',
          icon: Cpu
        };
      case 'feature_view':
        return {
          bg: 'bg-cyan-950/50',
          border: 'border-cyan-600/70',
          text: 'text-cyan-300',
          icon: Layers
        };
      case 'feature_service':
        return {
          bg: 'bg-emerald-950/50',
          border: 'border-emerald-600/70',
          text: 'text-emerald-300',
          icon: Zap
        };
      case 'model':
        return {
          bg: 'bg-purple-950/50',
          border: 'border-purple-600/70',
          text: 'text-purple-300',
          icon: Server
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Pipeline Filter Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            End-to-End Feature Lineage DAG
            <span className="text-xs font-mono font-normal text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800/50">
              Bi-Directional Provenance
            </span>
          </h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Trace Raw Data Sources</span>
            <span aria-hidden="true">·</span>
            <span>Transform Pipelines</span>
            <span aria-hidden="true">·</span>
            <span>Serving Features</span>
            <span aria-hidden="true">·</span>
            <span>Downstream Model Endpoints</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Pipeline filter */}
          <div className="flex items-center p-1 bg-[#111726] border border-slate-800 rounded-lg">
            <button
              onClick={() => setPipelineFilter('ALL')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                pipelineFilter === 'ALL'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Pipelines
            </button>
            <button
              onClick={() => setPipelineFilter('FRAUD')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                pipelineFilter === 'FRAUD'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Fraud Gateway
            </button>
            <button
              onClick={() => setPipelineFilter('RECSYS')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                pipelineFilter === 'RECSYS'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              RecSys Ranker
            </button>
          </div>

          {/* Zoom controls */}
          <div className="flex items-center gap-1 bg-[#111726] border border-slate-800 p-1 rounded-lg">
            <button
              onClick={() => setZoomLevel((z) => Math.max(0.7, z - 0.1))}
              className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono text-slate-400 px-1">
              {Math.round(zoomLevel * 100)}%
            </span>
            <button
              onClick={() => setZoomLevel((z) => Math.min(1.4, z + 0.1))}
              className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setZoomLevel(1)}
              className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200"
              title="Reset Zoom"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Canvas & Detail Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Interactive SVG Canvas */}
        <div className="lg:col-span-8 bg-[#070b11] border border-slate-800/90 rounded-xl relative overflow-hidden min-h-[580px]">
          {/* Legend */}
          <div className="absolute top-3 left-4 z-10 flex items-center gap-3 text-[11px] font-mono text-slate-400 bg-[#0b0f17]/90 px-3 py-1.5 rounded-lg border border-slate-800/80 backdrop-blur">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded bg-blue-500" />
              Source
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded bg-amber-500" />
              Transform
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded bg-cyan-400" />
              Feature View
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded bg-emerald-400" />
              Feature Service
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded bg-purple-400" />
              Model Endpoint
            </span>
          </div>

          {/* SVG Canvas */}
          <div
            className="w-full h-full overflow-auto p-8"
            style={{
              transform: `scale(${zoomLevel})`,
              transformOrigin: 'top left',
              transition: 'transform 0.15s ease-out'
            }}
          >
            <svg className="w-[1280px] h-[660px]" style={{ minWidth: 1280, minHeight: 660 }}>
              <defs>
                <marker
                  id="arrow-default"
                  viewBox="0 0 10 10"
                  refX="8"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 1 L 10 5 L 0 9 z" fill="#334155" />
                </marker>
                <marker
                  id="arrow-active"
                  viewBox="0 0 10 10"
                  refX="8"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 1 L 10 5 L 0 9 z" fill="#06b6d4" />
                </marker>
              </defs>

              {/* Render Connecting Edges */}
              {visibleEdges.map((edge) => {
                const sourceNode = visibleNodes.find((n) => n.id === edge.from);
                const targetNode = visibleNodes.find((n) => n.id === edge.to);
                if (!sourceNode || !targetNode) return null;

                const isConnected =
                  (selectedNodeId &&
                    ((sourceNode.id === selectedNodeId && downstreamNodeIds.has(targetNode.id)) ||
                      (targetNode.id === selectedNodeId && upstreamNodeIds.has(sourceNode.id)) ||
                      (upstreamNodeIds.has(sourceNode.id) && upstreamNodeIds.has(targetNode.id)) ||
                      (downstreamNodeIds.has(sourceNode.id) && downstreamNodeIds.has(targetNode.id)))) ||
                  false;

                const startX = sourceNode.x + 200;
                const startY = sourceNode.y + 40;
                const endX = targetNode.x;
                const endY = targetNode.y + 40;

                const controlX1 = startX + (endX - startX) * 0.5;
                const controlX2 = startX + (endX - startX) * 0.5;

                const pathData = `M ${startX} ${startY} C ${controlX1} ${startY}, ${controlX2} ${endY}, ${endX} ${endY}`;

                return (
                  <g key={edge.id}>
                    <path
                      d={pathData}
                      fill="none"
                      stroke={isConnected ? '#06b6d4' : '#1e293b'}
                      strokeWidth={isConnected ? 2.5 : 1.5}
                      strokeDasharray={isConnected ? 'none' : 'none'}
                      markerEnd={isConnected ? 'url(#arrow-active)' : 'url(#arrow-default)'}
                      className="transition-colors duration-200"
                    />
                    {edge.label && (
                      <text
                        x={(startX + endX) / 2}
                        y={(startY + endY) / 2 - 8}
                        fill="#64748b"
                        fontSize="9"
                        fontFamily="monospace"
                        textAnchor="middle"
                      >
                        {edge.label}
                      </text>
                    )}
                  </g>
                );
              })}

              {/* Render Nodes as SVG foreignObjects */}
              {visibleNodes.map((node) => {
                const isSelected = selectedNodeId === node.id;
                const isUpstream = upstreamNodeIds.has(node.id);
                const isDownstream = downstreamNodeIds.has(node.id);
                const isDimmed =
                  selectedNodeId && !isSelected && !isUpstream && !isDownstream;

                const style = getNodeColor(node.type);
                const IconComponent = style.icon;

                return (
                  <foreignObject
                    key={node.id}
                    x={node.x}
                    y={node.y}
                    width={200}
                    height={80}
                    className="overflow-visible"
                  >
                    <div
                      onClick={() => setSelectedNodeId(node.id)}
                      className={`w-[200px] h-[80px] p-3 rounded-xl border cursor-pointer select-none transition-all flex flex-col justify-between ${
                        style.bg
                      } ${
                        isSelected
                          ? 'border-cyan-400 ring-2 ring-cyan-500/30 shadow-lg shadow-cyan-900/40 scale-105 z-20'
                          : isUpstream || isDownstream
                          ? 'border-cyan-500/80 shadow-md'
                          : style.border
                      } ${isDimmed ? 'opacity-30' : 'opacity-100'}`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 truncate">
                          <IconComponent className={`w-3.5 h-3.5 ${style.text} shrink-0`} />
                          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">
                            {node.category}
                          </span>
                        </div>
                        {node.status === 'HEALTHY' ? (
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        ) : (
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                        )}
                      </div>

                      <div className="font-mono text-xs font-bold text-white truncate">
                        {node.name}
                      </div>

                      <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                        <span className="truncate">
                          {Object.values(node.meta)[0] || 'Nominal'}
                        </span>
                        {isSelected && (
                          <span className="text-cyan-400 font-bold uppercase text-[9px]">
                            Focus
                          </span>
                        )}
                      </div>
                    </div>
                  </foreignObject>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Node Inspector Sidebar */}
        <div className="lg:col-span-4">
          {selectedNode ? (
            <div className="bg-[#111726] border border-slate-800 rounded-xl p-5 space-y-5 sticky top-20 font-mono text-xs">
              <div className="flex items-start justify-between border-b border-slate-800 pb-4">
                <div>
                  <span className="text-[10px] text-cyan-400 uppercase tracking-wider block">
                    {selectedNode.category}
                  </span>
                  <h3 className="font-bold text-base text-white mt-0.5">{selectedNode.name}</h3>
                </div>
                <button
                  onClick={() => setSelectedNodeId(null)}
                  className="p-1 rounded text-slate-500 hover:text-slate-300"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Status and Health */}
              <div className="flex items-center justify-between bg-[#0b0f17] p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-400">Runtime Health:</span>
                <span className="flex items-center gap-1.5 font-bold text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {selectedNode.status}
                </span>
              </div>

              {/* Telemetry metadata */}
              <div className="space-y-2">
                <span className="text-slate-400 text-[11px] font-sans font-medium block">
                  Node Telemetry & Specifications:
                </span>
                <div className="bg-[#0b0f17] rounded-lg border border-slate-800 divide-y divide-slate-800/60">
                  {Object.entries(selectedNode.meta).map(([key, val]) => (
                    <div key={key} className="flex justify-between py-2 px-3 text-[11px]">
                      <span className="text-slate-500 uppercase">{key}:</span>
                      <span className="text-slate-200 font-semibold">{val}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Provenance context */}
              <div className="space-y-3 border-t border-slate-800 pt-4">
                <div>
                  <span className="text-[11px] text-slate-400 block font-sans font-medium mb-1">
                    Upstream Ancestors ({upstreamNodeIds.size}):
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {Array.from(upstreamNodeIds).map((id) => (
                      <span
                        key={id}
                        onClick={() => setSelectedNodeId(id)}
                        className="px-2 py-0.5 rounded bg-blue-950/60 border border-blue-800/40 text-blue-300 text-[10px] cursor-pointer hover:bg-blue-900/60"
                      >
                        {nodes.find((n) => n.id === id)?.name || id}
                      </span>
                    ))}
                    {upstreamNodeIds.size === 0 && (
                      <span className="text-slate-500 text-[11px]">Root Source (No upstream)</span>
                    )}
                  </div>
                </div>

                <div>
                  <span className="text-[11px] text-slate-400 block font-sans font-medium mb-1">
                    Downstream Consumers ({downstreamNodeIds.size}):
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {Array.from(downstreamNodeIds).map((id) => (
                      <span
                        key={id}
                        onClick={() => setSelectedNodeId(id)}
                        className="px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800/40 text-emerald-300 text-[10px] cursor-pointer hover:bg-emerald-900/60"
                      >
                        {nodes.find((n) => n.id === id)?.name || id}
                      </span>
                    ))}
                    {downstreamNodeIds.size === 0 && (
                      <span className="text-slate-500 text-[11px]">Leaf Consumer Endpoint</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Impact analysis note */}
              <div className="p-3 rounded-lg bg-cyan-950/30 border border-cyan-800/40 text-[11px] text-slate-300 font-sans leading-relaxed">
                <span className="text-cyan-400 font-bold block mb-0.5 font-mono">Impact Analysis:</span>
                Changes to this node will affect {downstreamNodeIds.size} downstream dependencies and 2 production model endpoints.
              </div>
            </div>
          ) : (
            <div className="bg-[#111726] border border-slate-800 rounded-xl p-8 text-center text-slate-500 text-xs font-mono">
              Click on any node in the DAG to inspect data lineage, upstream transforms, and downstream model consumers.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
