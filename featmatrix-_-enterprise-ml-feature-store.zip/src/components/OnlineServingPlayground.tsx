import React, { useState } from 'react';
import { FeatureService, FeatureView } from '../types/featureStore';
import {
  Zap,
  Play,
  Check,
  Copy,
  Terminal,
  Server,
  Layers,
  Sparkles,
  ArrowRight,
  Database,
  Cpu,
  Clock,
  RotateCcw
} from 'lucide-react';

interface OnlineServingPlaygroundProps {
  featureServices: FeatureService[];
  featureViews: FeatureView[];
  preselectedServiceId?: string;
}

export const OnlineServingPlayground: React.FC<OnlineServingPlaygroundProps> = ({
  featureServices,
  featureViews,
  preselectedServiceId
}) => {
  const [selectedServiceId, setSelectedServiceId] = useState<string>(
    preselectedServiceId || featureServices[0]?.id || ''
  );
  const [isQuerying, setIsQuerying] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState<'JSON' | 'PYTHON' | 'CURL' | 'GRPC'>('JSON');
  const [copiedSnippet, setCopiedSnippet] = useState(false);
  const [enableCache, setEnableCache] = useState(true);
  const [isBatchMode, setIsBatchMode] = useState(false);

  // Form Inputs for Entities
  const [userId, setUserId] = useState('usr_88291_a4');
  const [merchantId, setMerchantId] = useState('merch_elect_990');
  const [amountUsd, setAmountUsd] = useState('249.50');
  const [userLat, setUserLat] = useState('37.7749');
  const [userLon, setUserLon] = useState('-122.4194');
  const [merchantLat, setMerchantLat] = useState('37.7833');
  const [merchantLon, setMerchantLon] = useState('-122.4167');

  const selectedService =
    featureServices.find((s) => s.id === selectedServiceId) || featureServices[0];

  // Simulated Serving Response State
  const [queryResult, setQueryResult] = useState<any>(() => generateMockResponse(userId, merchantId, Number(amountUsd)));

  function generateMockResponse(uId: string, mId: string, amt: number) {
    const isFraudulent = amt > 1000 || uId.includes('99182');
    const latencyBase = 0.9;
    const kvTime = +(latencyBase + Math.random() * 0.4).toFixed(2);
    const transformTime = +(0.3 + Math.random() * 0.2).toFixed(2);
    const serializeTime = +(0.1 + Math.random() * 0.1).toFixed(2);
    const totalTime = +(kvTime + transformTime + serializeTime).toFixed(2);

    return {
      metadata: {
        feature_service: selectedService?.name || 'fraud_scoring_realtime_v4',
        version: selectedService?.version || 'v4.2',
        served_at: new Date().toISOString(),
        cache_hit: enableCache && Math.random() > 0.05,
        engine: 'Redis Enterprise Cluster (us-east-1a)',
        latency_breakdown_ms: {
          kv_lookup: kvTime,
          on_demand_python_transform: transformTime,
          serialization: serializeTime,
          total_e2e: totalTime
        }
      },
      entity_keys: {
        user_id: uId,
        merchant_id: mId
      },
      features: {
        // user_transaction_aggregates_30d
        'user_transaction_aggregates_30d:user_tx_count_30d': isFraudulent ? 68 : 24,
        'user_transaction_aggregates_30d:user_avg_tx_amount_30d': isFraudulent ? 480.2 : 84.5,
        'user_transaction_aggregates_30d:user_max_tx_amount_30d': isFraudulent ? 2100.0 : 420.0,
        'user_transaction_aggregates_30d:user_distinct_merchants_30d': isFraudulent ? 19 : 9,

        // user_realtime_velocity_1h
        'user_realtime_velocity_1h:user_tx_count_1h': isFraudulent ? 7 : 1,
        'user_realtime_velocity_1h:user_failed_auth_10m': isFraudulent ? 3 : 0,
        'user_realtime_velocity_1h:user_rapid_geo_switch_flag': isFraudulent,
        'user_realtime_velocity_1h:user_last_tx_amount': amt,

        // merchant_risk_profile
        'merchant_risk_profile:merchant_chargeback_rate_90d': 0.0042,
        'merchant_risk_profile:merchant_trust_tier': isFraudulent ? 'HIGH_RISK_TIER3' : 'VERIFIED_TIER1',
        'merchant_risk_profile:merchant_mcc_code': '5732',

        // on_demand cross features
        'user_merchant_cross_features:user_merchant_distance_km': 1.14,
        'user_merchant_cross_features:is_first_interaction_with_merchant': isFraudulent,
        'user_merchant_cross_features:tx_to_avg_amount_ratio': +(amt / 84.5).toFixed(2),

        // vector embedding
        'user_semantic_embedding:user_interest_vector': [
          0.124, -0.045, 0.881, -0.312, 0.054, 0.219, -0.618, 0.442,
          0.091, 0.155, -0.223, 0.518, -0.012, 0.334, -0.198, 0.076
        ]
      }
    };
  }

  const handleRunQuery = () => {
    setIsQuerying(true);
    setTimeout(() => {
      setQueryResult(generateMockResponse(userId, merchantId, Number(amountUsd)));
      setIsQuerying(false);
    }, 280);
  };

  const handleCopySnippet = (snippet: string) => {
    navigator.clipboard.writeText(snippet);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  const getPythonSnippet = () => {
    return `from featmatrix import FeatureStoreClient

client = FeatureStoreClient(
    endpoint="https://api.featmatrix.internal:443",
    api_key="fm_live_sec_99a8x0..."
)

# Sub-millisecond synchronous online retrieval
features = client.get_online_features(
    feature_service="${selectedService?.name}",
    entity_keys={
        "user_id": "${userId}",
        "merchant_id": "${merchantId}"
    },
    request_context={
        "amount_usd": ${amountUsd},
        "user_lat": ${userLat},
        "user_lon": ${userLon},
        "merchant_lat": ${merchantLat},
        "merchant_lon": ${merchantLon}
    }
)

print(f"P99 latency: {features.latency_ms} ms")
# Direct numpy / tensor consumption
model_input = features.to_tensor()`;
  };

  const getCurlSnippet = () => {
    return `curl -X POST https://api.featmatrix.internal/v1/features/online \\
  -H "Authorization: Bearer fm_live_sec_99a8x0..." \\
  -H "Content-Type: application/json" \\
  -d '{
    "feature_service": "${selectedService?.name}",
    "entity_keys": {
      "user_id": "${userId}",
      "merchant_id": "${merchantId}"
    },
    "request_context": {
      "amount_usd": ${amountUsd},
      "user_lat": ${userLat},
      "user_lon": ${userLon}
    }
  }'`;
  };

  const getGrpcSnippet = () => {
    return `// gRPC Proto definition for high-throughput C++/Go/Rust ML microservices
syntax = "proto3";
package featmatrix.serving.v1;

service OnlineServingService {
  rpc GetOnlineFeatures (GetOnlineFeaturesRequest) returns (GetOnlineFeaturesResponse);
}

message GetOnlineFeaturesRequest {
  string feature_service = 1;
  map<string, string> entity_keys = 2;
  map<string, double> request_context_numerical = 3;
}`;
  };

  return (
    <div className="space-y-6">
      {/* Title & SLA Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            Online Serving Engine
            <span className="text-xs font-mono font-normal text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/50">
              P99 &lt; 2.0ms Guaranteed
            </span>
          </h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Low-Latency Key-Value Feature Store</span>
            <span aria-hidden="true">·</span>
            <span>Redis Cluster & DynamoDB Global Tables</span>
            <span aria-hidden="true">·</span>
            <span>Real-time On-Demand Transforms</span>
          </div>
        </div>

        {/* Feature Service Switcher */}
        <div className="flex items-center gap-3">
          <label className="text-xs text-slate-400 font-medium">Active Service:</label>
          <select
            value={selectedServiceId}
            onChange={(e) => setSelectedServiceId(e.target.value)}
            aria-label="Active Feature Service"
            className="bg-[#111726] border border-slate-800 text-cyan-300 font-mono text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-cyan-500 font-semibold cursor-pointer"
          >
            {featureServices.map((svc) => (
              <option key={svc.id} value={svc.id}>
                {svc.name} ({svc.featuresCount} features, {svc.p99LatencyMs}ms)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid: Request Controls on Left, Live Telemetry & Response on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Request Builder */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#111726] border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                Entity Keys & Request Context
              </span>
              <div className="flex items-center gap-2">
                <label className="flex items-center gap-1.5 text-[11px] text-slate-400 cursor-pointer font-mono">
                  <input
                    type="checkbox"
                    checked={enableCache}
                    onChange={(e) => setEnableCache(e.target.checked)}
                    className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
                  />
                  <span>L1 Cache</span>
                </label>
              </div>
            </div>

            {/* Quick Preload Scenarios */}
            <div className="space-y-1.5">
              <span className="text-[11px] text-slate-400 font-mono block">Preload Test Scenario:</span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setUserId('usr_88291_a4');
                    setMerchantId('merch_elect_990');
                    setAmountUsd('149.00');
                  }}
                  className="px-2.5 py-1 text-xs rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-mono"
                >
                  Standard Consumer
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setUserId('usr_99182_ee');
                    setMerchantId('merch_luxury_772');
                    setAmountUsd('2400.00');
                  }}
                  className="px-2.5 py-1 text-xs rounded bg-rose-950/40 hover:bg-rose-900/50 text-rose-300 border border-rose-800/40 font-mono"
                >
                  High Risk (Drift/Spike)
                </button>
              </div>
            </div>

            {/* Inputs */}
            <div className="space-y-3 font-mono text-xs">
              <div>
                <label className="block text-slate-400 text-[11px] mb-1">
                  user_id (Primary Entity Key)
                </label>
                <input
                  type="text"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  className="w-full bg-[#0b0f17] border border-slate-800 rounded-lg px-3 py-1.5 text-cyan-300 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 text-[11px] mb-1">
                  merchant_id (Secondary Entity Key)
                </label>
                <input
                  type="text"
                  value={merchantId}
                  onChange={(e) => setMerchantId(e.target.value)}
                  className="w-full bg-[#0b0f17] border border-slate-800 rounded-lg px-3 py-1.5 text-cyan-300 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="border-t border-slate-800/80 pt-3">
                <span className="text-[11px] text-slate-400 font-sans block mb-2 font-medium">
                  Stateless Request Parameters (Used by On-Demand Python transforms):
                </span>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-500 block mb-0.5">amount_usd</label>
                    <input
                      type="number"
                      value={amountUsd}
                      onChange={(e) => setAmountUsd(e.target.value)}
                      className="w-full bg-[#0b0f17] border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-500 block mb-0.5">user_coords</label>
                    <input
                      type="text"
                      value={`${userLat}, ${userLon}`}
                      readOnly
                      className="w-full bg-[#0b0f17] border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-400 cursor-not-allowed"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Run Query CTA */}
            <button
              onClick={handleRunQuery}
              disabled={isQuerying}
              className="w-full py-2.5 px-4 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-medium text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-900/30 transition-all font-mono"
            >
              {isQuerying ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Fetching from Redis Cluster...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Execute Online Retrieval</span>
                </>
              )}
            </button>
          </div>

          {/* Performance breakdown card */}
          {queryResult && (
            <div className="bg-[#111726] border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between text-slate-400 text-[11px]">
                <span className="flex items-center gap-1.5 text-slate-300 font-semibold font-sans">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  Latency Breakdown (Total: {queryResult.metadata.latency_breakdown_ms.total_e2e}ms)
                </span>
                <span className="text-emerald-400 font-semibold">
                  {queryResult.metadata.cache_hit ? 'CACHE HIT' : 'CACHE MISS'}
                </span>
              </div>

              {/* Waterfall progress bar */}
              <div className="space-y-2 text-[11px]">
                <div>
                  <div className="flex justify-between text-slate-400 mb-1">
                    <span>Redis KV Read:</span>
                    <span className="text-cyan-400">
                      {queryResult.metadata.latency_breakdown_ms.kv_lookup} ms
                    </span>
                  </div>
                  <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-cyan-400 w-3/5 rounded-full" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-400 mb-1">
                    <span>On-Demand Transform:</span>
                    <span className="text-amber-400">
                      {queryResult.metadata.latency_breakdown_ms.on_demand_python_transform} ms
                    </span>
                  </div>
                  <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-amber-400 w-1/4 rounded-full" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-400 mb-1">
                    <span>Serialization:</span>
                    <span className="text-purple-400">
                      {queryResult.metadata.latency_breakdown_ms.serialization} ms
                    </span>
                  </div>
                  <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-purple-400 w-1/6 rounded-full" />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Code Generation & Live JSON Response */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#111726] border border-slate-800 rounded-xl overflow-hidden flex flex-col h-full">
            {/* Format Switcher Header */}
            <div className="bg-[#0b0f17] border-b border-slate-800 px-4 py-2.5 flex items-center justify-between">
              <div className="flex items-center gap-1">
                {(['JSON', 'PYTHON', 'CURL', 'GRPC'] as const).map((fmt) => (
                  <button
                    key={fmt}
                    onClick={() => setSelectedFormat(fmt)}
                    className={`px-3 py-1 text-xs font-mono rounded-md transition-colors ${
                      selectedFormat === fmt
                        ? 'bg-slate-800 text-cyan-400 font-bold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {fmt}
                  </button>
                ))}
              </div>

              <button
                onClick={() => {
                  const content =
                    selectedFormat === 'JSON'
                      ? JSON.stringify(queryResult, null, 2)
                      : selectedFormat === 'PYTHON'
                      ? getPythonSnippet()
                      : selectedFormat === 'CURL'
                      ? getCurlSnippet()
                      : getGrpcSnippet();
                  handleCopySnippet(content);
                }}
                className="flex items-center gap-1 text-xs text-slate-400 hover:text-slate-200"
              >
                {copiedSnippet ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 font-mono">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span className="font-mono">Copy</span>
                  </>
                )}
              </button>
            </div>

            {/* Display Body */}
            <div className="p-4 bg-[#070b11] font-mono text-xs overflow-y-auto max-h-[560px] leading-relaxed flex-1">
              {selectedFormat === 'JSON' && (
                <div className="space-y-4">
                  {/* Dense Vector visual preview if present */}
                  {queryResult?.features?.['user_semantic_embedding:user_interest_vector'] && (
                    <div className="bg-[#111726]/60 border border-slate-800 p-3 rounded-lg space-y-2">
                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span className="text-purple-400 font-bold flex items-center gap-1">
                          <Sparkles className="w-3.5 h-3.5" />
                          Vector Embedding (128-dim Float32)
                        </span>
                        <span>L2 Norm: 1.000</span>
                      </div>
                      <div className="flex gap-1 h-3 rounded overflow-hidden bg-slate-900">
                        {queryResult.features['user_semantic_embedding:user_interest_vector']
                          .slice(0, 16)
                          .map((val: number, idx: number) => {
                            const opacity = Math.min(Math.abs(val) * 1.5, 1);
                            const isPositive = val >= 0;
                            return (
                              <div
                                key={idx}
                                style={{
                                  backgroundColor: isPositive
                                    ? `rgba(168, 85, 247, ${opacity})`
                                    : `rgba(6, 182, 212, ${opacity})`
                                }}
                                className="flex-1 h-full"
                                title={`Dim ${idx}: ${val}`}
                              />
                            );
                          })}
                      </div>
                    </div>
                  )}

                  <pre className="text-slate-200">
                    {JSON.stringify(queryResult, null, 2)}
                  </pre>
                </div>
              )}

              {selectedFormat === 'PYTHON' && (
                <pre className="text-cyan-300">{getPythonSnippet()}</pre>
              )}

              {selectedFormat === 'CURL' && (
                <pre className="text-amber-300">{getCurlSnippet()}</pre>
              )}

              {selectedFormat === 'GRPC' && (
                <pre className="text-emerald-300">{getGrpcSnippet()}</pre>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
