import React, { useState } from 'react';
import {
  DataType,
  Entity,
  FeatureItem,
  FeatureView,
  TransformationType
} from '../types/featureStore';
import { X, Plus, Trash2, CheckCircle2, Layers, Database } from 'lucide-react';

interface CreateFeatureModalProps {
  isOpen: boolean;
  onClose: () => void;
  entities: Entity[];
  onCreate: (newFeatureView: FeatureView) => void;
}

export const CreateFeatureModal: React.FC<CreateFeatureModalProps> = ({
  isOpen,
  onClose,
  entities,
  onCreate
}) => {
  const [name, setName] = useState('');
  const [version, setVersion] = useState('v1.0');
  const [description, setDescription] = useState('');
  const [selectedEntity, setSelectedEntity] = useState(entities[0]?.joinKey || 'user_id');
  const [transformationType, setTransformationType] =
    useState<TransformationType>('BATCH_SQL');
  const [sourceEngine, setSourceEngine] = useState<
    'Snowflake' | 'Kafka' | 'BigQuery' | 'S3_Parquet' | 'PostgreSQL'
  >('Snowflake');
  const [sourceTable, setSourceTable] = useState('PROD_DB.ANALYTICS.EVENTS_DAILY');
  const [freshnessSlaMinutes, setFreshnessSlaMinutes] = useState(360);
  const [enableOnlineStore, setEnableOnlineStore] = useState(true);
  const [onlineEngine, setOnlineEngine] = useState<'Redis' | 'DynamoDB'>('Redis');

  const [features, setFeatures] = useState<
    Array<{ name: string; dataType: DataType; description: string; sampleValue: string }>
  >([
    {
      name: 'user_active_days_7d',
      dataType: 'INT64',
      description: 'Count of distinct days user logged in past 7 days',
      sampleValue: '5'
    },
    {
      name: 'user_conversion_score_pct',
      dataType: 'FLOAT32',
      description: 'Estimated checkout conversion probability score',
      sampleValue: '0.42'
    }
  ]);

  if (!isOpen) return null;

  const handleAddFeatureRow = () => {
    setFeatures((prev) => [
      ...prev,
      {
        name: `new_feature_${prev.length + 1}`,
        dataType: 'FLOAT32',
        description: 'New feature metric description',
        sampleValue: '1.0'
      }
    ]);
  };

  const handleRemoveFeatureRow = (index: number) => {
    setFeatures((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleFeatureChange = (index: number, field: string, value: string) => {
    setFeatures((prev) =>
      prev.map((item, idx) => (idx === index ? { ...item, [field]: value } : item))
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const featureItems: FeatureItem[] = features.map((f, idx) => ({
      id: `f_${name}_${idx}`,
      name: f.name,
      dataType: f.dataType,
      description: f.description,
      sampleValue:
        f.dataType === 'INT64'
          ? parseInt(f.sampleValue) || 0
          : f.dataType === 'FLOAT32'
          ? parseFloat(f.sampleValue) || 0.0
          : f.sampleValue,
      nullRatio: 0.001,
      driftPsi: 0.035,
      status: 'HEALTHY'
    }));

    const newFv: FeatureView = {
      id: `fv_${name.toLowerCase().replace(/[^a-z0-9_]/g, '_')}`,
      name: name.toLowerCase().replace(/[^a-z0-9_]/g, '_'),
      version,
      description,
      entities: [selectedEntity],
      transformationType,
      source: {
        engine: sourceEngine,
        tableOrTopic: sourceTable,
        description: 'Provisioned via FeatMatrix UI'
      },
      features: featureItems,
      onlineStore: {
        enabled: enableOnlineStore,
        engine: onlineEngine,
        ttlDays: 30,
        p99LatencyMs: 0.9,
        sizeMb: 120
      },
      offlineStore: {
        enabled: true,
        engine: sourceEngine === 'BigQuery' ? 'BigQuery' : 'Snowflake',
        partitionKey: 'DATE(event_timestamp)',
        schedule: '0 */6 * * *'
      },
      freshnessSlaMinutes,
      currentLagMinutes: 12,
      owner: 'ml-team@company.com',
      tags: ['custom', transformationType.toLowerCase(), 'new-release'],
      lastMaterializedAt: new Date().toISOString(),
      codeDefinition: `@${
        transformationType === 'STREAM_FLINK'
          ? 'stream_feature_view'
          : transformationType === 'ON_DEMAND_PYTHON'
          ? 'on_demand_feature_view'
          : 'batch_feature_view'
      }(
    sources=[${sourceEngine.toLowerCase()}_source],
    entities=[${selectedEntity}],
    online=${enableOnlineStore},
    description="${description || name}"
)
def ${name.toLowerCase().replace(/[^a-z0-9_]/g, '_')}(source):
    # Auto-generated feature transformation template
    return source.select("*")`
    };

    onCreate(newFv);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-[#111726] border border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl my-8 font-sans">
        {/* Header */}
        <div className="bg-[#0b0f17] border-b border-slate-800 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-cyan-950 border border-cyan-800/60 flex items-center justify-center text-cyan-400">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-white text-base">Create Feature View</h2>
              <span className="text-xs text-slate-400">Register new ML features for serving and training</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 text-xs">
          {/* Row 1: Name and Version */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2 space-y-1">
              <label className="text-slate-300 font-semibold font-mono">
                Feature View Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. user_checkout_velocity_7d"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#0b0f17] border border-slate-800 rounded-lg px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div className="space-y-1">
              <label className="text-slate-300 font-semibold font-mono">Version</label>
              <input
                type="text"
                value={version}
                onChange={(e) => setVersion(e.target.value)}
                className="w-full bg-[#0b0f17] border border-slate-800 rounded-lg px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {/* Description */}
          <div className="space-y-1">
            <label className="text-slate-300 font-semibold font-mono">Description</label>
            <input
              type="text"
              placeholder="What signals or business logic does this feature view capture?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-[#0b0f17] border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Row 2: Entity & Transformation Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-slate-300 font-semibold font-mono">Join Entity</label>
              <select
                value={selectedEntity}
                onChange={(e) => setSelectedEntity(e.target.value)}
                className="w-full bg-[#0b0f17] border border-slate-800 rounded-lg px-3 py-2 text-cyan-300 font-mono focus:outline-none focus:border-cyan-500"
              >
                {entities.map((ent) => (
                  <option key={ent.id} value={ent.joinKey}>
                    {ent.name} ({ent.joinKey})
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-semibold font-mono">
                Transformation Engine
              </label>
              <select
                value={transformationType}
                onChange={(e) => setTransformationType(e.target.value as TransformationType)}
                className="w-full bg-[#0b0f17] border border-slate-800 rounded-lg px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
              >
                <option value="BATCH_SQL">Batch SQL (Spark / Snowflake)</option>
                <option value="STREAM_FLINK">Stream (Apache Flink / Kafka)</option>
                <option value="ON_DEMAND_PYTHON">On-Demand Python (Stateless)</option>
                <option value="EMBEDDING">Dense Vector Embedding</option>
              </select>
            </div>
          </div>

          {/* Row 3: Source Config & SLA */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-slate-300 font-semibold font-mono">Source Storage</label>
              <select
                value={sourceEngine}
                onChange={(e) => setSourceEngine(e.target.value as any)}
                className="w-full bg-[#0b0f17] border border-slate-800 rounded-lg px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
              >
                <option value="Snowflake">Snowflake</option>
                <option value="Kafka">Kafka Topic</option>
                <option value="BigQuery">Google BigQuery</option>
                <option value="S3_Parquet">AWS S3 Parquet</option>
                <option value="PostgreSQL">PostgreSQL</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-semibold font-mono">Freshness SLA</label>
              <select
                value={freshnessSlaMinutes}
                onChange={(e) => setFreshnessSlaMinutes(Number(e.target.value))}
                className="w-full bg-[#0b0f17] border border-slate-800 rounded-lg px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
              >
                <option value={1}>1 minute (Real-time Stream)</option>
                <option value={60}>1 hour (Near Real-time)</option>
                <option value={360}>6 hours (Batch)</option>
                <option value={1440}>24 hours (Daily)</option>
              </select>
            </div>
          </div>

          {/* Features Builder */}
          <div className="space-y-2 border-t border-slate-800 pt-4">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white font-mono uppercase text-[11px] tracking-wider">
                Features Schema ({features.length})
              </span>
              <button
                type="button"
                onClick={handleAddFeatureRow}
                className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 font-mono"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Feature</span>
              </button>
            </div>

            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {features.map((feat, idx) => (
                <div
                  key={idx}
                  className="grid grid-cols-12 gap-2 bg-[#0b0f17] p-2 rounded-lg border border-slate-800 items-center font-mono"
                >
                  <div className="col-span-5">
                    <input
                      type="text"
                      placeholder="feature_name"
                      value={feat.name}
                      onChange={(e) => handleFeatureChange(idx, 'name', e.target.value)}
                      className="w-full bg-transparent text-slate-200 text-xs focus:outline-none border-b border-transparent focus:border-cyan-500"
                    />
                  </div>

                  <div className="col-span-3">
                    <select
                      value={feat.dataType}
                      onChange={(e) => handleFeatureChange(idx, 'dataType', e.target.value)}
                      className="w-full bg-[#111726] border border-slate-800 rounded px-1.5 py-1 text-[11px] text-cyan-300"
                    >
                      <option value="FLOAT32">FLOAT32</option>
                      <option value="INT64">INT64</option>
                      <option value="STRING">STRING</option>
                      <option value="BOOLEAN">BOOLEAN</option>
                      <option value="VECTOR_128">VECTOR_128</option>
                    </select>
                  </div>

                  <div className="col-span-3">
                    <input
                      type="text"
                      placeholder="sample value"
                      value={feat.sampleValue}
                      onChange={(e) => handleFeatureChange(idx, 'sampleValue', e.target.value)}
                      className="w-full bg-transparent text-slate-400 text-[11px] focus:outline-none"
                    />
                  </div>

                  <div className="col-span-1 text-right">
                    <button
                      type="button"
                      onClick={() => handleRemoveFeatureRow(idx)}
                      disabled={features.length <= 1}
                      className="text-slate-500 hover:text-rose-400 disabled:opacity-30"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Online Serving Toggle */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-[#0b0f17] border border-slate-800 font-mono">
            <div>
              <span className="text-white font-semibold block">Enable Online Low-Latency Store</span>
              <span className="text-slate-500 text-[11px] font-sans">
                Materialize to Redis cluster for sub-2ms key-value inference
              </span>
            </div>
            <input
              type="checkbox"
              checked={enableOnlineStore}
              onChange={(e) => setEnableOnlineStore(e.target.checked)}
              className="w-4 h-4 rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-0"
            />
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-slate-400 hover:text-slate-200 text-xs font-mono"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-medium text-xs font-mono shadow-md shadow-cyan-900/30"
            >
              Register Feature View
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
